package wikisteps;

public class WikiStepDefinition 
{

}
