package githubsteps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GithubStepDefinition 
{
	private WebDriver driver;
	
	@Given("^user is on the login page$")
	public void user_is_on_the_login_page() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\savuda\\Downloads\\BDD_Files\\chromedriver/chromedriver.exe");
		driver= new ChromeDriver();
		driver.navigate().to("https://github.com/login?return_to=%2Fgithub");
		Thread.sleep(2000);
	    
	}

	@When("^user clicks on the login button$")
	public void user_clicks_on_the_login_button() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("login")).sendKeys("vudanagakishore");;
		driver.findElement(By.name("password")).sendKeys("Leelakishore@123");;
		Thread.sleep(5000);
	    
	}

	@Then("^it  succesfull login$")
	public void it_succesfull_login() throws InterruptedException  {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("commit")).submit();
		Thread.sleep(2000);
		driver.close();
	}
	
	


	
}
