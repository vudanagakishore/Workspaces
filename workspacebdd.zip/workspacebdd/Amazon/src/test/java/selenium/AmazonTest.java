package selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonTest 
{
	private static WebDriver driver;
	public static void main(String args [])
	{
		 System.setProperty("webdriver.chrome.driver","C:/Users/savuda/Downloads/BDD_Files/chromedriver/chromedriver.exe");
		 driver = new ChromeDriver();
	     driver.manage().window().maximize();
	     driver.manage().deleteAllCookies();
	     driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	     driver.get("https://www.amazon.in/");
	     System.out.println(driver.getCurrentUrl());;
	     driver.findElement(By.xpath("//*[@id=\"nav-xshop\"]/a[2]")).click();
	}
	
	

}















//hooks before run and after run