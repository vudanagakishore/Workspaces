package selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FreeCRMSignup 
{	
	private static WebDriver driver;      //declaration
	
	public static void main(String args[])
	{
		//File file = new File("C:/Users/savuda/Downloads/BDD_Files/chromedriver/chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver", file.getPath());
		 System.setProperty("webdriver.chrome.driver","C:/Users/savuda/Downloads/BDD_Files/chromedriver/chromedriver.exe");
	     driver = new ChromeDriver();
	     driver.manage().window().maximize();
	     driver.manage().deleteAllCookies();
	     driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	     driver.get("https://freecrm.com");
	//signin     //driver.findElement(By.xpath("/html/body/div[1]/main/section[1]/a")).click();
	/*login
	 * */  WebElement element=driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/div[2]/div/div[2]/ul/a/span[2]"));//this is used for referencing the path
	element.click();//using reference object to click the appropriate button
	}
}
