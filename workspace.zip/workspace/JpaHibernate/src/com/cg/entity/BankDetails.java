package com.cg.entity;
import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="BankInformation")
public class BankDetails {
@Id
private int accountId;
@Column(length=20)
private String accountantName;
@Column(length=10)
private String contactNo;
//private String address;
@Column(length=10)
private int accountBalance;
@OneToOne
private TransactionDetails t;


public TransactionDetails getT() {
	return t;
}

public void setT(TransactionDetails t) {
	this.t = t;
}
//Random Function
public int ran(int min, int max){
	Random r=new Random();
	return r.nextInt((max-min)+1)+min;
}

public int getAccountId() {
	return accountId;
}
public void setAccountId() {
	this.accountId = ran(1000,9999);
}
public String getAccountantName() {
	return accountantName;
}
public void setAccountantName(String accountantName) {
	this.accountantName = accountantName;
}
public String getContactNo() {
	return contactNo;
}
public void setContactNo(String mobileno) {
	this.contactNo = mobileno;
}
public int getAccountBalance() {
	return accountBalance;
}
public void setAccountBalance(int accBalance) {
	this.accountBalance = accBalance;
}
}
