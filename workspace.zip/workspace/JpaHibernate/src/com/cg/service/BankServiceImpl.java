package com.cg.service;

import com.cg.dao.BankDaoImpl;
import com.cg.entity.BankDetails;
import com.cg.entity.TransactionDetails;

public class BankServiceImpl implements IBankService {
 BankDaoImpl daoObj=new BankDaoImpl();
 
	@Override
	
	public BankDetails getAccountById(int id) {
	BankDetails bank  = daoObj.getAccountById(id) ;
		return bank;
	}

	@Override
	public void CreateAccount(BankDetails bank) {
		daoObj.beginTransaction();
		daoObj.CreateAccount(bank);
		daoObj.commitTransaction();
	}

	@Override
	public void ShowBalance(BankDetails bank) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Deposit(BankDetails bank) {
		daoObj.beginTransaction();
		daoObj.Deposit(bank);	
		daoObj.commitTransaction();
 
	}

	@Override
	public void Withdraw(BankDetails bank) {
		daoObj.beginTransaction();
		daoObj.Withdraw(bank);
		daoObj.commitTransaction();
	}

	@Override
	public void PrintTransactions(int id) {
		daoObj.PrintTransactions(id);
		
	}

	@Override
	public void commitTransaction() {
		daoObj.commitTransaction();
		
	}

	@Override
	public void beginTransaction() {
		daoObj.beginTransaction();
	}

	public void addTransaction(TransactionDetails trans) {

		daoObj.beginTransaction();
		daoObj.addTransaction(trans);
		daoObj.commitTransaction();
	}
	 
}

