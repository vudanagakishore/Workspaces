package com.cg.ui;
import java.util.Scanner;

import com.cg.entity.BankDetails;
import com.cg.entity.TransactionDetails;
import com.cg.service.BankServiceImpl;
public class MainUi {
	public static void Menu()
	{
		System.out.println("\n\n\n*************Your BANK ***************");
	
		System.out.println("1. CreateAccount\n2. Show Balance\n3. Deposit\n4. WithDraw\n5. Fund Transfer\n6. Print Transaction\n7. Exit");
	
	}
	public static void main(String[] args) throws InvalidException {
		do{
			Menu();
		
		 Scanner scannerObj=new Scanner(System.in);
		 BankServiceImpl serviceObj=new BankServiceImpl();
		 BankDetails bank=new BankDetails();
		 TransactionDetails trans=new TransactionDetails();
		 TransactionDetails trans1=new TransactionDetails();
	 int opt=scannerObj.nextInt();
		 
	 switch(opt)
	 {
	 case 1:
		 System.out.println("Fill the reqiured details to create Account\n");
		 System.out.println("Enter Account Name");
		 String name=scannerObj.next();
		 if(name==null||name.length()>12)
		 {
			 throw new InvalidException("Enter valid Name ");
		 }
		 System.out.println("Enter Mobile Number");
		 String mobileno=scannerObj.next();
		 if(mobileno.length()!=10)
		 {
			 throw new InvalidException("Enter valid Mobile Number");
		 }
		 
		 bank.setAccountId();
		 bank.setAccountantName(name);
		 bank.setContactNo(mobileno);
		 bank.setAccountBalance(1000);
		 
		 
		 serviceObj.CreateAccount(bank);		//Service class calling
		 
		 System.out.println("Inserted Successfully ......");
		 int id=bank.getAccountId();
		 serviceObj.getAccountById(id);
		 System.out.println("Your ACCOUNT ID is :"+bank.getAccountId());
		 
		
	  break;
	 case 2:
		 System.out.println("Enter your account id for Balance enquiry");
		 int accid=scannerObj.nextInt();
		 if(accid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=serviceObj.getAccountById(accid);
		 System.out.println("Accountant Name: "+bank.getAccountantName());
		 System.out.println(" YOur Account Balance is: "+bank.getAccountBalance());
		
		 break;
		 
	 case 3:
		 System.out.println("Deposit Module...!!");
		 System.out.println("Enter your Account ID");
		 int depId=scannerObj.nextInt();
		 if(depId==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=serviceObj.getAccountById(depId);	
		 System.out.println("Accountant Name: "+bank.getAccountantName());
		 System.out.println(" Your Account Balance is: "+bank.getAccountBalance());
		 int initbal=bank.getAccountBalance();
		 System.out.println("Enter the Amount you want to Deposit");
		 int depAmt=scannerObj.nextInt();
		 int finalbal=initbal+depAmt;
		 bank.setAccountBalance(finalbal);
		 serviceObj.Deposit(bank);

		 //Updating In Transaction Table
		 
		 trans.setTransactionType("Deposit");
		 trans.setAccId(depId);
		 trans.setAmount(depAmt);
		 serviceObj.addTransaction(trans);
		 bank.setT(trans);
		 
		 
		 bank=serviceObj.getAccountById(depId);
		 System.out.println("Hello  "+bank.getAccountantName());
		 System.out.println("Your Account Balance after Depositing "+depAmt+" Rs is "+bank.getAccountBalance());
		
		 break;
	 case 4:
		 System.out.println("Withdraw Module");
		 System.out.println("Enter your account Id");
		 int wid=scannerObj.nextInt();
		 if(wid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=serviceObj.getAccountById(wid);						
		 System.out.println("Hello... "+bank.getAccountantName());
		 System.out.println(" Your Account Balance is: "+bank.getAccountBalance());
		 int intbal=bank.getAccountBalance();							//initial balance
		 
		 System.out.println("Enter the Amount you want to Withdraw");
		 int wamt=scannerObj.nextInt();
		 int finalBal=intbal-wamt;
		 bank.setAccountBalance(finalBal);
		 serviceObj.Withdraw(bank);
 		 
 		 
		 //Updating In Transaction Table
		 trans.setTransactionType("Withdraw");
		 trans.setAccId(wid);
		 trans.setAmount(wamt);
		 serviceObj.addTransaction(trans);
		 bank.setT(trans);
		 
		 bank=serviceObj.getAccountById(wid);
		 System.out.println("Hello ................ "+bank.getAccountantName());
		 System.out.println("Your Remaining Account Balance after Withdraw "+wamt+" Rs is"+bank.getAccountBalance());
		
		 break;
	 case 5:
		 System.out.println("Fund Transfer....!!");
		 System.out.println("Enter the From Account ID");
		 int fid=scannerObj.nextInt();	//From Account Id (Sender)
		 if(fid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 bank=serviceObj.getAccountById(fid);
		 int bal=bank.getAccountBalance();						//Initial Balance
		 System.out.println("Enter the amount you want to transfer");
		 int fund=scannerObj.nextInt();	//Amount to be transfered
		 System.out.println("Enter Reciever Account Id");
		 
		 int tid=scannerObj.nextInt();
		 if(tid==0)
		 {
			 throw new InvalidException("Enter valid Account Id");
		 }
		 
		//Removing the Balance transfered from sender Account 
		 bank=serviceObj.getAccountById(fid);
		 int bal1=bal-fund;
		 bank.setAccountBalance(bal1);
		 serviceObj.Deposit(bank);
		 
		 //updating the Balance recieved from Sender
		 bank=serviceObj.getAccountById(tid);
		 int tbal=bank.getAccountBalance();
		 int tbalance=tbal+fund;
		 bank.setAccountBalance(tbalance);
		 serviceObj.Deposit(bank);
		
		 
		 //updating In transaction Table
		 trans.setTransactionType("Transfered to "+tid);
		 trans.setAccId(fid);
		 trans.setAmount(fund);
		 serviceObj.addTransaction(trans);
		 bank.setT(trans);
		 int a= trans.getTransactionId();
		 
		/*//Updating In transaction Table
		 trans1.setTransactionId(a);
		 trans1.setTransactionType("Recieved From"+fid);
		 trans1.setAccId(tid);
		 trans1.setAmount(fund);
		 service.addTransaction(trans1);
		 bank.setT(trans1);
		 
		 */
		
		 bank=serviceObj.getAccountById(fid);
		 System.out.println("helooo...."+bank.getAccountantName());
		 System.out.println("Remaining balance in account "+bank.getAccountBalance());
		 
		 break;
		 
	 case 6:
		System.out.println("Print Transaction");
		System.out.println("Enter the account id");
		int trid=scannerObj.nextInt();
		//trans.setAccId(trid);
		serviceObj.PrintTransactions(trid);
		
		 break;
	 case 7:
		 System.out.println("Thankyou For using our Bank Services...................!!!");
		 System.exit(0);
	 }
	}while(true);
}
}