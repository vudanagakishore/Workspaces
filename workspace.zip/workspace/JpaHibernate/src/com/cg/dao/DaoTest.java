package com.cg.dao;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class DaoTest {
	BankDaoImpl bankDaoImpl = new BankDaoImpl();
	
	@Test
	public void Search()
	{
		assertTrue("This will succeed.", true);
		//assertTrue("This will fail!", false);
	}

}
